
package Hardware;


public class DepositSlot {
    public boolean isEnvelopeReceived() {
        return true; // deposit envelope was received
    }
}
